n=int(input("enter the number :"))
if n==0:
    print(n," number is zero")
elif n>0:
    print(n," number is positive")
else:
    print(n,"number is nagative")