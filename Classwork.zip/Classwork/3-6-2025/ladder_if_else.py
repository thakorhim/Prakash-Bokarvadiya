n=int(input("Enter your age :"))

if n>100:
    print(n,"invalide age")
elif n>=18:
    print(n,"You can vote")
else:
    print(n,"is note  valid for vote")
