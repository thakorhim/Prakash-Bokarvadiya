a=int(input("enter the number :"))
b=int(input("enter the number :"))
c=int(input("enter the number :"))
if a>b:
    if a>c:
        print(a,"is greaterst")
    else:
        print(c,"is greaterst")
else:
    if b>c:
        print(b,"is greaterst")
    else:
        print(c,"is greaterst")