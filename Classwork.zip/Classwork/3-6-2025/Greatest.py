n=int(input("enter the number:"))
z=int(input("enter the number:"))
if n==z:
    print(n,"is equal to",z)
elif n>z:
    print(n,"is greater than",z)
else:
    print(z,"is greater than",n)