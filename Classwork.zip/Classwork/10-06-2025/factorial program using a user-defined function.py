#factorial program using a user-defined function
def fact():
    n=int(input("enter a number : "))
    fact=1
    while n>0:
        fact=fact*n
        n=n-1
    print(fact)
fact()
