# calculator.py
a=int(input("Enter Number A : "))
b=int(input("Enter Number B : "))

print("A : ",a)
print("B : ",b)


if b == 0:
    {
        print ("Error: Cannot divide by zero!")
    }

print("1. Addition (+):",a+b)
print("2. Subtraction (-):",a-b)
print("3. Multiplication (*):",a*b)
print("4. Division (/):",a/b)

        