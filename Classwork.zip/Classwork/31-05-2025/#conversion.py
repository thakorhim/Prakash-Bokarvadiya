#conversion 

n=int(input("Enter Days : "))
years=n/365
print("Years are : ",years)
weeks = years * 52
print("week : ",weeks)
months = weeks / 4.3

print("Months: ",months)

years = months / 12
print("Years :",years)
