print("Hello",end="  ")
print("Welcome")

a=20
b=40

print("A : ",a)
print("B : ",b)