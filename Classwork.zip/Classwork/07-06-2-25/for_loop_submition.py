num = int(input("Enter the number :"))
i = 0
sum = 0
for i in range(1,num+1):
    sum = sum + i
print("Sum of the number is :",sum)