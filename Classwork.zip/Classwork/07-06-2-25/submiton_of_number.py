num =int( input("Enter the number: "))
i=1
sum=0
while (i<=num):    
    sum=sum+i
    i=i+1
print(sum)