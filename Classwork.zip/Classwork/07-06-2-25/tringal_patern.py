#uper side of tringal
#     *
#    * *    
#   * * *
#  * * * *
# * * * * *

for i in range(1,20):
    for j in range(1,i+1):
        print(" ",end=" ")
        if j>=20-i:
            print("*",end=" ")
        else:
            print(" ",end=" ")
    print()
    