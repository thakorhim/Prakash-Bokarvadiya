n=int(input("Enter a number: "))
fact=1
while(n>0):
    fact=fact*n
    #n=3
    #1=1*3
    #3=3*2
    #6=6*1
    n=n-1
print("Factorial of the number is: ",fact)